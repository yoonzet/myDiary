module.exports = {
  mongoURI:
    "mongodb+srv://yoon:dlapdlf1@cluster0.2ac5iv3.mongodb.net/?retryWrites=true&w=majority", 
};
